<?php
/**
 * Templated sections init
 *
 * @package shark_magazine
 */

/**
 * Add template hooks defaults.
 */
require get_template_directory() . '/inc/template-hooks/slider.php';